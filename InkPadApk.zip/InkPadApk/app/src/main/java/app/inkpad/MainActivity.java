package app.inkpad;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;

import androidx.webkit.WebViewAssetLoader;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.vision.digitalink.DigitalInkRecognition;
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModel;
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModelIdentifier;
import com.google.mlkit.vision.digitalink.DigitalInkRecognizer;
import com.google.mlkit.vision.digitalink.DigitalInkRecognizerOptions;
import com.google.mlkit.vision.digitalink.Ink;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";
    private WebView web;
    private final Map<String, DigitalInkRecognizer> recognizers = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage и IndexedDB (блокноты хранятся здесь)
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        // Страница отдаётся с виртуального https-адреса, чтобы IndexedDB и localStorage работали штатно
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
            }
        });

        // В WebView confirm() и prompt() по умолчанию молча возвращают «нет», поэтому показываем свои окна
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { result.confirm(); }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override public void onCancel(DialogInterface d) { result.cancel(); }
                        })
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { result.confirm(); }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { result.cancel(); }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override public void onCancel(DialogInterface d) { result.cancel(); }
                        })
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, final JsPromptResult result) {
                final EditText input = new EditText(MainActivity.this);
                input.setSingleLine(true);
                input.setText(defaultValue);
                input.setSelectAllOnFocus(true);
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(message)
                        .setView(input)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { result.confirm(input.getText().toString()); }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int w) { result.cancel(); }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override public void onCancel(DialogInterface d) { result.cancel(); }
                        })
                        .show();
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "InkPadAndroid");

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START_URL);
        }
    }

    /** Методы, которые страница вызывает через window.InkPadAndroid. */
    private class Bridge {

        /**
         * Распознавание рукописного текста (ML Kit, работает на устройстве).
         * json — массив строк, строка — массив штрихов, штрих — массив точек [x, y, t].
         * Ответ приходит в window.__inkDone(id, {lines: [[вариант, ...], ...]} или {error}).
         */
        @JavascriptInterface
        public void recognize(final String id, final String json, final String lang) {
            try {
                final JSONArray lines = new JSONArray(json);
                DigitalInkRecognitionModelIdentifier mid = DigitalInkRecognitionModelIdentifier.fromLanguageTag(lang);
                if (mid == null) {
                    reply(id, null, "Язык не поддерживается");
                    return;
                }
                final DigitalInkRecognitionModel model = DigitalInkRecognitionModel.builder(mid).build();
                final DigitalInkRecognizer recognizer;
                synchronized (recognizers) {
                    DigitalInkRecognizer r = recognizers.get(lang);
                    if (r == null) {
                        r = DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(model).build());
                        recognizers.put(lang, r);
                    }
                    recognizer = r;
                }
                final RemoteModelManager manager = RemoteModelManager.getInstance();
                manager.isModelDownloaded(model)
                        .addOnSuccessListener(downloaded -> {
                            if (downloaded) {
                                step(id, lines, 0, new JSONArray(), recognizer);
                            } else {
                                status(id, "download");
                                manager.download(model, new DownloadConditions.Builder().build())
                                        .addOnSuccessListener(v -> step(id, lines, 0, new JSONArray(), recognizer))
                                        .addOnFailureListener(e -> reply(id, null,
                                                "не удалось скачать языковую модель. Проверьте интернет (возможно, нужен VPN)"));
                            }
                        })
                        .addOnFailureListener(e -> reply(id, null, String.valueOf(e.getMessage())));
            } catch (Exception e) {
                reply(id, null, String.valueOf(e.getMessage()));
            }
        }

        @JavascriptInterface
        public boolean savePng(String name, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                v.put(MediaStore.Downloads.MIME_TYPE, "image/png");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return false;
                OutputStream out = getContentResolver().openOutputStream(uri);
                if (out == null) return false;
                try {
                    out.write(data);
                } finally {
                    out.close();
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }

    /** Распознаёт строки по очереди, у каждой берёт до четырёх вариантов. */
    private void step(final String id, final JSONArray lines, final int i, final JSONArray out, final DigitalInkRecognizer rec) {
        if (i >= lines.length()) {
            reply(id, out, null);
            return;
        }
        try {
            JSONArray strokes = lines.getJSONArray(i);
            Ink.Builder ink = Ink.builder();
            for (int s = 0; s < strokes.length(); s++) {
                JSONArray pts = strokes.getJSONArray(s);
                Ink.Stroke.Builder sb = Ink.Stroke.builder();
                for (int p = 0; p < pts.length(); p++) {
                    JSONArray pt = pts.getJSONArray(p);
                    sb.addPoint(Ink.Point.create((float) pt.getDouble(0), (float) pt.getDouble(1), pt.getLong(2)));
                }
                ink.addStroke(sb.build());
            }
            rec.recognize(ink.build())
                    .addOnSuccessListener(result -> {
                        JSONArray cands = new JSONArray();
                        int n = Math.min(4, result.getCandidates().size());
                        for (int c = 0; c < n; c++) {
                            cands.put(result.getCandidates().get(c).getText());
                        }
                        out.put(cands);
                        step(id, lines, i + 1, out, rec);
                    })
                    .addOnFailureListener(e -> reply(id, null, String.valueOf(e.getMessage())));
        } catch (Exception e) {
            reply(id, null, String.valueOf(e.getMessage()));
        }
    }

    private void reply(final String id, final JSONArray lines, final String error) {
        String payload;
        try {
            JSONObject o = new JSONObject();
            if (error != null) {
                o.put("error", error);
            } else {
                o.put("lines", lines);
            }
            payload = o.toString();
        } catch (Exception e) {
            payload = "{\"error\":\"ошибка\"}";
        }
        final String js = "window.__inkDone('" + id + "'," + payload + ")";
        runOnUiThread(() -> {
            if (web != null) {
                web.evaluateJavascript(js, null);
            }
        });
    }

    private void status(final String id, final String st) {
        runOnUiThread(() -> {
            if (web != null) {
                web.evaluateJavascript("window.__inkStatus&&window.__inkStatus('" + id + "','" + st + "')", null);
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onPause() {
        // Страница сохраняет блокнот по событию pagehide — вызываем его вручную при уходе из приложения
        web.evaluateJavascript("window.dispatchEvent(new Event('pagehide'))", null);
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        synchronized (recognizers) {
            for (DigitalInkRecognizer r : recognizers.values()) {
                r.close();
            }
            recognizers.clear();
        }
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
