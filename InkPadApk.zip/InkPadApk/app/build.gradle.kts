plugins {
    id("com.android.application")
}

android {
    namespace = "app.inkpad"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.inkpad"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.google.mlkit:digital-ink-recognition:18.1.0")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
}
